package com.wipro.hrms.model;

import java.util.List;

public class App {

	public static void main(String[] args) {
		BranchDaoImpl bdao=new BranchDaoImpl();
//		List<Branch> branches = bdao.read();
//		for(Branch b:branches)
//		{
//			System.out.println(b);
//		}
//		Branch branch = bdao.read("B00103");
//		System.out.println(branch);
		
//		Branch b=new Branch("B00126", "Wipro 3 branch...", "Bengaluru");
//		bdao.create(b);
//		bdao.update(b);
		bdao.delete("B00126");
	}

}
